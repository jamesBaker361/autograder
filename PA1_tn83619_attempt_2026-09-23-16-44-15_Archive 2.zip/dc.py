""" starter file for pa1: dogcat """

import search       # AIMA module for search problems
import gzip         # read from a gzip'd file

# file name for the dictionary, with one word per line.  Each line
# will have a word followed by a tab followed by a number, e.g.
#   and     0.07358445
#   for     0.18200336

dict_file = "words34.txt.gz"

# dictionary is a dict to hold legal 3 and 4 letter words with their
# frequencies based on a sample of a large text corpus. The dict's
# keys are the words and its values are their frequencies

# load words into the dictionary dict
dictionary = {}
for line in gzip.open(dict_file, 'rt'):
    word, n = line.strip().split('\t')
    n = float(n)
    dictionary[word] = n

# Scrabble letter values as specified in the assignment (section 2.2).
# Keys are lowercase for convenience.
_SCRABBLE_GROUPS = {
    1: "AEIOULNSTR",
    2: "DG",
    3: "BCMP",
    4: "FHVWY",
    5: "K",
    6: "JX",
    10: "QZ",
}
SCRABBLE = {}
for _val, _letters in _SCRABBLE_GROUPS.items():
    for _ch in _letters:
        SCRABBLE[_ch.lower()] = _val

# Minimum rarity over the whole dictionary. Since every frequency-cost
# action pays 1 + rarity(word) and rarity >= 0, every action costs at
# least 1 + MIN_RARITY.
MIN_RARITY = min(dictionary.values())


class DC(search.Problem):
    """DC is a subclass of the AIMA search files's Problem class. Its init
       method takes three arguments: the initial word, goal word, and cost method.
       A state is represented as a lowercase string of three or four
       ascii characters.  Both the initial and goal states must be
       words of the same length and they must be in the dict
       dictionary. The cost argument specifies how to measure the
       cost of an action and can be 'steps', 'scrabble' or 'frequency'
       """

    def __init__(self, initial='dog', goal='cat', cost='steps'):
        # validate cost measure
        if cost not in ('steps', 'scrabble', 'frequency'):
            raise ValueError(f"cost must be one of 'steps', 'scrabble', 'frequency', got {cost!r}")

        # validate words: lowercase strings of 3 or 4 letters, same length,
        # and present in the dictionary
        for name, word in (('initial', initial), ('goal', goal)):
            if not isinstance(word, str):
                raise ValueError(f"{name} word must be a string, got {type(word).__name__}")
            if len(word) not in (3, 4):
                raise ValueError(f"{name} word must have 3 or 4 letters, got {word!r}")
            if not word.isalpha() or not word.islower():
                raise ValueError(f"{name} word must be a lowercase string, got {word!r}")
        if len(initial) != len(goal):
            raise ValueError(
                f"initial and goal must have the same length, got {initial!r} and {goal!r}"
            )
        if initial not in dictionary:
            raise ValueError(f"initial word {initial!r} not in dictionary")
        if goal not in dictionary:
            raise ValueError(f"goal word {goal!r} not in dictionary")

        super().__init__(initial, goal)
        self.cost = cost

    def actions(self, state):
        """ Given a state (i.e., a word), return a list or iterator of
        all possible next actions.  An action is defined by position
        in the word and a character to put in that position.  But the
        result must be a legal word, i.e., in our dictionary, and it
        should not be the same as the state, i.e., don't replace a
        character with the same character """

        acts = []
        for i in range(len(state)):
            prefix = state[:i]
            suffix = state[i + 1:]
            orig = state[i]
            for ch in 'abcdefghijklmnopqrstuvwxyz':
                if ch == orig:
                    continue
                new_word = prefix + ch + suffix
                if new_word in dictionary:
                    acts.append((i, ch))
        return acts

    def result(self, state, action):
        """ takes a state and an action and returns a new state """
        pos, ch = action
        return state[:pos] + ch + state[pos + 1:]

    def goal_test(self, state):
        """ returns True iff state is a goal state for this problem instance """
        return state == self.goal

    def path_cost(self, c, state1, action, state2):
        """ Returns the cost to get to state2 by applying action in
        state1 given that c is the cost to get up to state1. For the
        the dc problem, you will have to check what
        cost metric (self.cost) is being used for this problem instance,
        i.e., is it steps, scrabble or frequency """
        if self.cost == 'steps':
            return c + 1
        elif self.cost == 'scrabble':
            # cost is the value of the newly inserted letter
            _pos, new_letter = action
            return c + SCRABBLE[new_letter]
        elif self.cost == 'frequency':
            # entering word state2 costs 1 + rarity(state2)
            return c + 1 + dictionary[state2]
        else:  # pragma: no cover - guarded in __init__
            raise ValueError(f"unknown cost measure {self.cost!r}")

    def __repr__(self):
        """" return a suitable string to represent this problem instance """
        return f"dc({self.initial},{self.goal},{self.cost})"

    def h(self, node):
        """Heuristic: returns an estimate of the cost to get from the
        state of the node to the goal state. The heuristic's value should
        depend on the Problem's cost parameter, self.cost (i.e., steps, scrabble
        or frequency), as this will effect the estimate cost to get to
        the nearest goal. """
        state = node.state
        goal = self.goal
        if state == goal:
            return 0

        # number of positions that still differ
        diff = sum(1 for a, b in zip(state, goal) if a != b)

        if self.cost == 'steps':
            # Every action fixes at most one position and costs 1,
            # so at least `diff` actions are still needed.
            return diff
        elif self.cost == 'scrabble':
            # Each differing position i must at some point be overwritten
            # with goal[i], and that single action costs SCRABBLE[goal[i]].
            # Distinct positions need distinct actions, so the sum is a
            # lower bound on the remaining cost.
            return sum(
                SCRABBLE[b] for a, b in zip(state, goal) if a != b
            )
        elif self.cost == 'frequency':
            # At least `diff` more words must be entered. The last one is
            # the goal itself, costing 1 + rarity(goal); every other one
            # costs at least 1 + MIN_RARITY.
            return (diff - 1) * (1 + MIN_RARITY) + (1 + dictionary[goal])
        else:  # pragma: no cover - guarded in __init__
            raise ValueError(f"unknown cost measure {self.cost!r}")
