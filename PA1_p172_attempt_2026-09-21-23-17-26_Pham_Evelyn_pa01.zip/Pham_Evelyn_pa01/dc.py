""" starter file for pa1: dogcat """

import search       # AIMA module for search problems
import gzip         # read from a gzip'd file

# file name for the dictionary, with one word per line.  Each line
# will have a word followed by a tab followed by a number, e.g.
#   and     0.07358445
#   for     0.18200336

dict_file = "words34.txt.gz"

# dictionary is a dict to hold legal 3 and 4 letter words with their
# frequencies based on a sample of a large text corpus. The dict's
# keys are the words and its values are their frequencies

# load words into the dictionary dict
dictionary = {}
for line in gzip.open(dict_file, 'rt'):
    word, n = line.strip().split('\t')
    n = float(n)
    dictionary[word] = n

class DC(search.Problem):
    """DC is a subclass of the AIMA search files's Problem class. Its init
       method takes three arguments: the initial word, goal word, and cost method.
       A state is represented as a lowercase string of three or four
       ascii characters.  Both the initial and goal states must be
       words of the same length and they must be in the dict
       dictionary. The cost argument specifies how to measure the
       cost of an action and can be 'steps', 'scrabble' or 'frequency'
       """

    def __init__(self, initial='dog', goal='cat', cost='steps'):
        # set instance attributes ...
        # validate initial and goal words must be strings
        if not isinstance(initial, str) or not isinstance(goal, str):
            raise ValueError("Initial and goal must be strings")
        
        # validate initial and goal words must be lowercase
        if not initial.islower() or not goal.islower():
            raise ValueError("Initial and goal must be lowercase")
        
        # validate initial and goal words must contains either three or four letters
        if len(initial) not in (3, 4) or len(goal) != len(initial):
            raise ValueError("Words should contain either three or four letters")
        
        # validate initial and goal words must appear in the provided dictionary
        if initial not in dictionary or goal not in dictionary:
            raise ValueError("Words must appear in the provided dictionary")
        
        if cost not in ('steps', 'scrabble', 'frequency'):
            raise ValueError("Invalid cost measures")
        
        super().__init__(initial, goal)

        # store the cost method
        self.cost = cost

    def actions(self, state):
        """ Given a state (i.e., a word), return a list or iterator of
        all possible next actions.  An action is defined by position
        in the word and a character to put in that position.  But the
        result must be a legal word, i.e., in our dictionary, and it
        should not be the same as the state, i.e., don't replace a
        character with the same character """

        possible_actions = []
        for i in range(len(state)):
            for letter in "abcdefghijklmnopqrstuvwxyz":
                # check whether letter differs from state[i]
                if letter != state[i]:
                    # construct the new word
                    new_state = state[:i] + letter + state[i+1:]
                    # check whether the new word is in dictionary
                    if new_state in dictionary:
                        # if valid, add to possible_actions
                        possible_actions.append((i, letter))
        return possible_actions
    
    def result(self, state, action):
        """ takes a state and an action and returns a new state """
        i, letter = action
        new_state = state[:i] + letter + state[i+1:]
        return new_state
    
    def goal_test(self, state):
        """ returns True iff state is a goal state for this problem instance """
        return state == self.goal

    def path_cost(self, c, state1, action, state2):
        """ Returns the cost to get to state2 by applying action in
        state1 given that c is the cost to get up to state1. For the 
        the dc problem, you will have to check what
        cost metric (self.cost) is being used for this problem instance,
        i.e., is it steps, scrabble or frequency """
        if self.cost == 'steps':
            return c + 1
        elif self.cost == 'scrabble':
            letter = action[1]
            if letter in "aeioulnstr":
                return c + 1
            elif letter in "dg":
                return c + 2
            elif letter in "bcmp":
                return c + 3
            elif letter in "fhvwy":
                return c + 4
            elif letter in "k":
                return c + 5
            elif letter in "jx":
                return c + 6
            elif letter in "q,z":
                return c + 10
            
        elif self.cost == 'frequency':
            return c + 1 + dictionary[state2]

    def __repr__(self):
        """" return a suitable string to represent this problem instance """
        return f"dc({self.initial}, {self.goal}, {self.cost})"

    def h(self, node):
        """Heuristic: returns an estimate of the cost to get from the
        state of the node to the goal state. The heuristic's value should
        depend on the Problem's cost parameter, self.cost (i.e., steps, scrabble
        or frequency), as this will effect the estimate cost to get to
        the nearest goal. """
        # get the current word from the search node 
        state = node.state
        differences = sum(1 for i in range(len(state))
                          if state[i] != self.goal[i])

        # get the step cost
        if self.cost == 'steps':
            return differences

        elif self.cost == 'scrabble':
            return sum(self.path_cost(0, state, (i, self.goal[i]), self.goal)
                       for i in range(len(state))
                       if state[i] != self.goal[i])
        elif self.cost == 'frequency':
            if differences == 0:
                return 0
            
            return differences + dictionary[self.goal]
            
            